# Merchant Bottom Navigation Concept V1 — implementer review

Status: **implementer_reviewed**

Date: 2026-10-03

This is not visual acceptance. Tests and mocked screenshots only support
implementer review.

The Concept V1 reference image was not present in the workspace. The written
specification was the visual source. Stitch page content and existing Merchant
routing / business behaviour were left in place.

## 1. Files changed

| Path | Change |
| --- | --- |
| `lib/app/theme/app_theme.dart` | `MerchantNavTokens` plus Concept V1 colours |
| `lib/core/constants/app_strings.dart` | `navReveal` |
| `lib/features/shell/merchant_nav_visibility.dart` | hide / reveal controller |
| `lib/features/shell/merchant_bottom_nav.dart` | floating dock, handle, slot |
| `lib/features/shell/merchant_shell.dart` | persistent pager + dock slot |
| `test/features/merchant_bottom_nav_test.dart` | focused unit / widget tests |
| `test/audit/parity/bottom_nav_v1_capture_test.dart` | mocked captures 1.0 / 1.35 |

Unchanged: `lib/app/router/app_router.dart` route table, tab paths and order,
nested `parentNavigatorKey` pushes, auth, APIs, permissions, Customer, Driver,
backend, previous audit ZIPs.

## 2. Navigation architecture

Root tabs stay **pages inside one persistent shell**, not pushed routes.

- `GoRouter` still uses `ShellRoute` + `context.go` on the five tab paths:
  Accueil, Commandes, Catalogue, Rapports, Profil.
- `MerchantShell` keeps a `PageView` of those five screens with
  `AutomaticKeepAliveClientMixin`. Returning to a tab does not remount it.
- Tab taps call `context.go`, then the shell animates the pager (220 ms,
  `easeOutCubic`, subtle fade).
- Intentional horizontal swipes change the pager, then `context.go` updates
  the URL.
- Nested detail / editor / workflow routes still use `parentNavigatorKey` on
  the root navigator. The dock is not forced onto those screens.
- Deep links to a tab path select that page. Android back from a pushed route
  pops to the shell and shows the dock.

The `ShellRoute` child is still built by go_router. The pager owns the
long-lived instances so a later `HomeScreen()` from the route builder does not
replace the kept page.

## 3. Hide / reveal rules

Controller: `MerchantNavVisibilityController`.

Only the **selected** root page’s **primary vertical** scroll is used
(`ScrollNotification.depth == 0`, `axis == vertical`). Nested horizontal chips,
carousels and the pager itself are ignored.

| Event | Result |
| --- | --- |
| Finger-driven scroll down, accumulated ≥ 48 px | Hide (slide down + fade, 200 ms) |
| Finger-driven scroll up (any delta < 0) | Reveal immediately |
| `pixels <= minScrollExtent` (top) | Reveal |
| Handle tap | Reveal |
| Root tab change | Reveal |
| Return from a nested route to an exact tab path | Reveal |
| App resume | Reveal |
| Keyboard (`viewInsets.bottom > 0`) | Auto-hide off (stays revealed) |
| Focus inside a `TextField` / `EditableText` | Auto-hide off |
| `accessibleNavigation` | Auto-hide off |
| Shell route not current (dialog / pushed cover) | Auto-hide off |
| Ballistic settle / rebound (`dragDetails == null`) | Ignored (anti-jitter) |

Hidden chrome is a centered 32×4 muted handle above the safe area
(`Key('nav-handle')`).

## 4. Root transition and state preservation

- Duration 220 ms; direction follows tab order.
- Reduced motion (`disableAnimations`) jumps without the fade.
- Scroll offset and in-page widgets (for example a typed field) survive tab
  changes because the page stays in the `PageView`.
- Riverpod controllers on those pages are not recreated on return, so the
  screens do not fire a fresh load solely because the user came back.
- Pages are created lazily on first visit (builder), then kept.

## 5. Test matrix

| Case | Result |
| --- | --- |
| Each active tab state | **PASS** |
| Selected accessibility semantics | **PASS** |
| Scroll-down hide threshold | **PASS** |
| Scroll-up immediate reveal | **PASS** |
| Handle-tap reveal | **PASS** |
| No jitter around the threshold | **PASS** |
| Tab-tap horizontal transition | **PASS** |
| Intentional swipe transition | **PASS** |
| Preserved scroll position | **PASS** |
| Preserved page state | **PASS** |
| Nested horizontal scroll does not change tabs | **PASS** |
| Keyboard / form does not auto-hide | **PASS** |
| Small-screen safe area | **PASS** |
| Text scale 1.35 | **PASS** |
| App background / resume | **PASS** |
| Deep link to a root tab | **PASS** |
| Android back from nested route | **PASS** |
| Last row does not overlap the dock | **PASS** |
| Tab change reveals a hidden dock | **PASS** |
| `merchant_polish_geometry_test` | **PASS** |
| Phase 1 “home empty orders and tab navigation” | **PASS** |
| Order-list visual corrections, startup, widget_test | **PASS** |
| Mocked captures 1.0 and 1.35 | **PASS** |
| Full `test/features` suite | **NOT RUN** (focused + listed regressions only) |
| Live Merchant captures | **NOT RUN** (see §6) |

`dart analyze` on the touched files: clean except a pre-existing
`prefer_const_constructors` info on `ColorScheme.light` in `app_theme.dart`.

## 6. Evidence paths

Mocked (this pass only):

`apps/merchant_app/audit/parity/bottom_nav/mocked/`

- `nav_accueil_w390.png` / `nav_accueil_w375_t135.png`
- `nav_commandes_w390.png` / `nav_commandes_w375_t135.png`
- `nav_catalogue_w390.png` / `nav_catalogue_w375_t135.png`
- `nav_rapports_w390.png` / `nav_rapports_w375_t135.png`
- `nav_profil_w390.png` / `nav_profil_w375_t135.png`
- `nav_hidden_w390.png` / `nav_hidden_w375_t135.png`
- `nav_dock_only_w390.png` / `nav_dock_only_w375_t135.png`

Checksums: `apps/merchant_app/audit/parity/bottom_nav/SHA256SUMS`.

Live: **NOT RUN**. Disk preflight was `DISK_PREFLIGHT_OK free_gb=6` (tight).
A live shot would need fixture OTP login, which is a session mutation. The
brief asked for read-only live evidence only when no session or data change
is required. Finjan, Keychain, and existing sessions were not touched.
Port 3000 was not started.

Review ZIP (new, does not replace earlier packages):

`apps/merchant_app/audit/parity/bottom_nav/review/merchant_bottom_nav_v1_2026-10-03_review.zip`

Previous polish / contract / opening-hours review ZIPs were not modified.

## 7. Known gaps

- No Concept V1 bitmap was in the repo. Capsule colour, radius and shadow
  follow the written spec (`#E8EEFF` capsule, 24 px dock radius, deep
  `#0A4096` active, muted gray inactive). A reviewer should compare to the
  approved image.
- At width 390 and text scale 1.0 the five French labels are tight. They use
  `FittedBox` and do not clip at 1.35; they are still the same strings and
  order.
- `nav_dock_only_*.png` can show a faint extra icon row in the empty body.
  That is a standalone-scaffold capture artifact. The shell captures are the
  ones to review.
- Horizontal overscroll at the end of a nested chip row may still be claimed
  by the root `PageView`. Chip-row drags in the focused test did not change
  tabs.
- Ballistic (finger-up) scroll is ignored so hide/reveal does not jitter.
  A flick that is almost entirely ballistic after a short drag still hides or
  reveals from the drag portion.
- Auto-hide during an unnamed confirmation sheet uses “shell route is not
  current”. Sheets that do not change `ModalRoute.isCurrent` are not
  specially detected beyond keyboard / focus.
- The five tab widgets are constructed by the shell as well as by the
  `GoRoute` builders. Only the pager instances are shown.
- Wider Merchant suite and live device shots were not run.

## 8. Untouched

Customer app, Driver app, backend data, `speedygo_dev`, Finjan, Dar El Bahja,
Keychain, existing sessions, Firebase, Maps, Chargily, SMS, Redis, port 3000,
git commit, push, and deploy were not used or changed.

## 9. Final status

**implementer_reviewed**
