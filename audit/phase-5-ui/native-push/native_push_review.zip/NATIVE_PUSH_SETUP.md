# Native Push setup — Merchant new orders (v1.1)

Status: **implementer_reviewed**. Code is in place. Real delivery needs the credentials below. Contract: [`NOTIFICATIONS_FOUNDATION.md` → Native Push v1.1](./NOTIFICATIONS_FOUNDATION.md#native-push-v11-merchant_order_created).

## Provider decision

| Option | Decision |
| --- | --- |
| **FCM HTTP v1** (Android native; iOS through an APNs auth key uploaded to Firebase) | **Chosen.** One backend adapter and one client plugin (`firebase_messaging`) cover both platforms. `FCM_PROJECT_ID` was already reserved in `.env.example`. |
| Direct APNs + separate FCM | Rejected: two adapters and two token types for the same feature. |
| Third-party (OneSignal, etc.) | Rejected: new vendor and data processor, not needed. |

The backend has **no new dependency**: OAuth uses a service-account JWT signed with `node:crypto` (RS256) and HTTP uses `fetch`. The merchant app adds `firebase_core` and `firebase_messaging`. iOS uses Swift Package Manager and there is no Podfile.

## What never goes in Git

| Secret / config | Where it lives |
| --- | --- |
| Firebase service-account JSON (backend) | Outside every repo, e.g. `~/.speedygo/dev/fcm-service-account.json` (`chmod 600`). Production: the deployment secret store, mounted as a file. |
| APNs auth key `.p8` | Uploaded to Firebase Console only. The backend never reads it. |
| Firebase client options (merchant) | `apps/merchant_app/config/push.local.json` (gitignored). CI: generated from secrets at build time. |

Client Firebase options (API key, app ids) are not server secrets, but they are still kept out of Git so each environment can point at its own Firebase project.

## Checklist (user steps)

### 1. Firebase project

1. Create or select a Firebase project (a separate one per environment is recommended).
2. Enable **Firebase Cloud Messaging API (V1)** (Google Cloud Console → APIs).

### 2. iOS

1. In Firebase, add an **iOS app** with bundle id `com.speedygo.speedygoMerchantApp`.
2. In Apple Developer (team `HVDAQ6R4SW`):
   - Enable the **Push Notifications** capability for that App ID.
   - Create an **APNs Auth Key (.p8)** and note the Key ID.
3. In Firebase Console → Project settings → Cloud Messaging → Apple app configuration, upload the `.p8` with its Key ID and Team ID.
4. Regenerate provisioning profiles so they include `aps-environment`. The repo already has:
   - `ios/Runner/Runner.entitlements` with `aps-environment = development`. Release/TestFlight builds must be signed with `production`; Xcode sets this automatically when archiving with a distribution profile.
   - `Info.plist` `UIBackgroundModes = [remote-notification]`.
5. Test on a **physical iPhone**, or on an Apple-silicon Mac simulator running iOS 16+ that is signed into an Apple ID. A physical device is the only acceptable release evidence.

### 3. Android

1. In Firebase, add an **Android app** with package `com.speedygo.speedygo_merchant_app`.
2. You do **not** need `google-services.json`: the app passes `FirebaseOptions` from dart-defines.
3. The repo already has:
   - the `POST_NOTIFICATIONS` permission (Android 13+ runtime prompt)
   - the default channel `merchant_new_orders` ("Nouvelles commandes", importance HIGH), created in `MainActivity`.

### 4. Backend service account

1. Firebase Console → Project settings → Service accounts → **Generate new private key**.
2. Save it outside the repo, e.g. `~/.speedygo/dev/fcm-service-account.json`, then run `chmod 600`.
3. Set these in `apps/backend/.env` (never committed):

| Key | Value |
| --- | --- |
| `PUSH_PROVIDER` | `fcm` (default `disabled`) |
| `FCM_PROJECT_ID` | Firebase project id. Must equal `project_id` inside the JSON, or Push stays `SKIPPED_NOT_CONFIGURED`. |
| `FCM_SERVICE_ACCOUNT_FILE` | Absolute path to the JSON |
| `PUSH_SEND_MAX_ATTEMPTS` | Optional, default `5` |
| `PUSH_SEND_BACKOFF_MS` | Optional, default `2000` (exponential) |
| `PUSH_REQUEST_TIMEOUT_MS` | Optional, default `10000` |
| `PUSH_PENDING_SWEEP_MIN_AGE_MS` | Optional, default `60000` |
| `FCM_API_BASE_URL` | Leave empty. Non-production contract-stub override only; ignored when `NODE_ENV=production`. |

4. Restart the backend. The gateway validates the file on first use and caches the result for the life of the process, so restart after changing it. It logs only the problem class (never key material). If the file is invalid, Push stays `SKIPPED_NOT_CONFIGURED`.

### 5. Merchant app client options

1. Copy `config/push.example.json` to `config/push.local.json` and fill in:

| Key | Firebase Console source |
| --- | --- |
| `SGO_FIREBASE_API_KEY` | iOS/Android app → "Web API key" / `API_KEY` |
| `SGO_FIREBASE_PROJECT_ID` | Project id |
| `SGO_FIREBASE_SENDER_ID` | Cloud Messaging sender id (`GCM_SENDER_ID`) |
| `SGO_FIREBASE_IOS_APP_ID` | iOS app id (`1:…:ios:…`) |
| `SGO_FIREBASE_ANDROID_APP_ID` | Android app id (`1:…:android:…`) |
| `SGO_FIREBASE_IOS_BUNDLE_ID` | `com.speedygo.speedygoMerchantApp` |

2. Run or build with `--dart-define-from-file=config/push.local.json`.
3. If any key is empty, the app runs with Push **unavailable**. The settings screen says so, and the foreground poll and inbox are unaffected.

## Verification after credentials exist

Use the Dar El Bahja fixture and an isolated device or session. Do not use Finjan.

| Check | How | Evidence |
| --- | --- | --- |
| Token registration | Sign in, grant permission | `device_tokens` row active for the Dar owner account |
| Provider acceptance | Create an order | Push log `PROVIDER_ACCEPTED`, `providerReference=fcm:projects/…/messages/…` |
| Background receipt | App in background, create an order | OS banner screenshot on the device |
| Terminated receipt + tap | Force-quit, create an order, tap the banner | Opens the correct order detail after sign-in / branch ready |
| Foreground dedupe | App open, create an order | Exactly one in-app alert, no OS banner |
| Stale | Accept or cancel before tapping | Snackbar "stale"; not shown as awaiting acceptance |
| Logout | Sign out | Token `active=false` |
| Permission denied | Deny in system settings, resume the app | Settings show denied; token deactivated |

`PROVIDER_ACCEPTED` alone is **not** device-receipt proof.
